package com.ayush;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoEmpApplicationTests {

	@Test
	void contextLoads() {
	}

}
